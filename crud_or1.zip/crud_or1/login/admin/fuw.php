<!DOCTYPE html>
<html>
<head>
	<title>Login Admin Minimarket Berkah</title>
</head>
<body>
	<h2>Halaman Admin</h2>
	
	<br/>
 
	<?php 
	session_start();
	if($_SESSION['status']!="login"){
		header("location:../index.php?pesan=belum_login");
	}
	?>
 
	<h4>Selamat datang, <?php echo $_SESSION['username']; ?>! Anda telah Login. <?php echo date ("l- M- Y");?> </h4>
 
	<br/>
	<br/>
 
 	<a href="index.php">Data</a>
	<a href="logout.php">LOGOUT</a>
 
 
</body>
</html>