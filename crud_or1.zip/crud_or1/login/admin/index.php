<?php
  include('koneksi.php'); //penguhubung dengan database
  
?>

<!DOCTYPE html>
<html>
  <head>
      <link rel="stylesheet" type="text/css" href="style.css">

    <title>CRUD Produk Minimarket Berkah</title>
    <style type="text/css"> // untuk memberikan hiasan pada tampilan web
      * {
        font-family: "Rockwell, Calibri, Monospace, Times New Roman";
        font-variant: all;
        font-size: 20px;
      }
      h1 {
        text-transform: uppercase; //biar kapital
        color: black;
      }
    table {
      border: solid 1px #DDEEEE;
      border-collapse: collapse;
      border-spacing: 0;
      width: 70%;
      margin: 10px auto 10px auto;
    }
    table thead th {
        background-color: #DDEFEF;
        border: solid 1px #DDEEEE;
        color: #336B6B;
        padding: 10px;
        text-align: left;
        text-shadow: 1px 1px 1px #fff;
        text-decoration: none;
    }
    table tbody td {
        border: solid 1px #DDEEEE;
        color: #333;
        padding: 10px;
        text-shadow: 1px 1px 1px #fff;
    }
    a {
          background-color: salmon;
          color: #fff;
          padding: 10px;
          text-decoration: none;
          font-size: 12px;
    }
    </style>
  </head>
  <body>

    <center><h1>Daftar Data Produk. <?php echo date("l, d-M-Y"); ?></h1><center>
    <center><a href="tambah_produk.php">+ &nbsp; Tambahkan Produk</a><center>
    <center> <br><a href="Stok_barang.php">+ &nbsp; Stok Barang</a> </br> <center>
    <center> <h1> <a href="logout.php">+ &nbsp; Logout</a></h1><center>

    <br/>
    <table>
    <thead>
      <tr>
        <th>No</th>
        <th>Produk</th>
        <th>Dekripsi</th>
        <th>Harga Beli</th>
        <th>Harga Jual</th>
        <th>Gambar</th>
        <th>Pilihan</th>


      </tr>
    </thead>
    <tbody>
      <?php
      
      $query = "SELECT * FROM makanan ORDER BY id ASC";
      $result = mysqli_query($koneksi, $query);
      
      if(!$result){
        die ("Query Error: ".mysqli_errno($koneksi).
           " - ".mysqli_error($koneksi));
      }
      $no = 1; 
      
      while($row = mysqli_fetch_assoc($result))
      {
      ?>
       <tr>
          <td><?php echo $no; ?></td>
          <td><?php echo $row['nama_produk']; ?></td>
          <td><?php echo substr($row['deskripsi'], 0, 20); ?>...</td>
          <td>Rp <?php echo number_format($row['harga_beli'],0,',','.'); ?></td>
          <td>Rp <?php echo $row['harga_jual']; ?></td>
          <td style="text-align: center;"><img src="gambar/<?php echo $row['gambar_produk']; ?>" style="width: 120px;"></td>
          <td>
             <a href="edit_produk.php?id=<?php echo $row['id']; ?>">Edit</a>|
              <a href="proses_hapus.php?id=<?php echo $row['id']; ?>" onclick="return confirm('Anda yakin akan menghapus data ini?')">Hapus</a>
          </td>
      </tr>
         
      <?php
        $no++; 
        //agar nomor terus bertambah 1
      }
      ?>
    </tbody>
    </table>
  </body>
</html>